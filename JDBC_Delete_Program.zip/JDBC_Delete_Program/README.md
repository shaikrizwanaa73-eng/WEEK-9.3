# JDBC Delete Data Lab (3.1)

## Aim
Connect to MySQL using JDBC and delete the user record with ID 2 from the
`users` table using a `PreparedStatement` and a `WHERE` condition.

## Requirements
- Java JDK installed
- MySQL Server running
- MySQL Connector/J JDBC driver
- Database `mydatabase` and table `users` with an `id` column

## Configure your credentials
Open `src/JDBCDelete.java` and replace `your_password` with your MySQL password.
If your MySQL username is not `root`, update `USERNAME` too.

## Compile and run
Make sure the MySQL Connector/J JAR is available. If it is named
`mysql-connector-j.jar` and placed in this project folder:

### macOS / Linux
```bash
javac -cp ".:mysql-connector-j.jar" -d out src/JDBCDelete.java
java -cp "out:mysql-connector-j.jar" JDBCDelete
```

### Windows
```bat
javac -cp ".;mysql-connector-j.jar" -d out src/JDBCDelete.java
java -cp "out;mysql-connector-j.jar" JDBCDelete
```

## Expected output
If a row with ID 2 exists:
```text
Row deleted successfully.
```

If no row with ID 2 exists:
```text
No rows were deleted.
```

**Note:** This program permanently deletes the row with ID 2. Make sure you
are connected to the intended database before running it. It uses try-with-resources
to close JDBC resources automatically.
