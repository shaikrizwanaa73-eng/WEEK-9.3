Save your actual execution screenshot in this folder as output_1.png or output_1.jpg.
The program output depends on your local MySQL database contents.
